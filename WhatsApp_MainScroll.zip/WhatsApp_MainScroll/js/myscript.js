﻿var startPage = function() {
  var _fnEvents = function() {
    console.log("abc");

    var lastScrollTop = 0;
    $(".app-body").scroll(function(event) {
      var st = $(this).scrollTop();
      if (st > lastScrollTop) {
        var temp = $(".app-header-main").height() - (st - lastScrollTop) / 4;
        temp = temp >= 0 ? temp : 0;
        $(".app-header-main").css("height", temp);
      } else {
        if ($(".app-header-main").height() < 30) {
          var temp = $(".app-header-main").height() + (lastScrollTop - st);
          $(".app-header-main").css("height", temp);
        } else{
            $(".app-header-main").css("height", $('.app-header-main').css('max-height'));
        }
      }
      lastScrollTop = st;
    });
  };

  return {
    init: function() {
      _fnEvents();
    }
  };
};

$(document).ready(function() {
  document.addEventListener("deviceready", function() {
    if (DronaHQ.IsReady) {
      var thisScript = new startPage();
      thisScript.init();
    }
  });

  //removoe later
  var thisScript = new startPage();
  thisScript.init();
});
